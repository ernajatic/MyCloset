package com.ernajaticipia.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TurskaAngora extends JFrame{
    private JPanel panel1;
    private JButton nazadButton;
    private JButton zatvoriButton;
    private JTextPane turskaAngoraJednaJeTextPane;

    private JFrame frame;

    public TurskaAngora(){

        // Za svaku macu je sve isto osim slike i opisa te slike

        frame = new JFrame("Turska Angora");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(400, 400));
        frame.setResizable(false);

        frame.add(panel1);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // Ako korisnik izabere Zatvori program se zatvara

        zatvoriButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        // Ako korisnik izabere Nazad ova Forma se dispose-a i kreira se Ormar ponovo (ne znam kako da samo vratim na istu Ormar formu bez da kreiram novu)

        nazadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Ormar();
                dispose();
            }
        });
    }
}
