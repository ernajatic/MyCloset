package com.ernajaticipia.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dobrodoslica extends JFrame{
    private JPanel panel1;
    private JButton nastaviButton;
    private JButton zatvoriButton;
    private JLabel label1;

    private JFrame frame;

    public Dobrodoslica(){

        // Sve isto kao LogIn Frame

        frame = new JFrame("Dobrodošli!");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(300, 300));
        frame.setResizable(false);


        frame.add(panel1);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        //Ako korisnik odabere dugme Zatvori program se prekida

        zatvoriButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        // Ako korisnik odabere dugme Nastavi, ide se na slijedeći Frame

        nastaviButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Ormar();
                dispose();
            }
        });
    }
}
