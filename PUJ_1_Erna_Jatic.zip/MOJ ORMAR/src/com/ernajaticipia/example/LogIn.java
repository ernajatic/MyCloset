package com.ernajaticipia.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogIn extends JFrame {
    private JTextField txtUser;
    private JPanel panel1;
    private JPasswordField txtPassword;
    private JButton logInButton;

    private JFrame frame;

    // Konstruktor
    public LogIn() {

        //P omoć - Indijci preko YouTuba-a

        frame = new JFrame("LogIn"); // Ime našeg prozora
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE); // Aplikacija se zatvara kada korisnik kliken X
        frame.setPreferredSize(new Dimension(300, 300));// Postavljanje veličine prozora
        frame.setResizable(false);// Korisnik ne može mijenjati veličinu prozora

        frame.add(panel1);// Dodajemo naš panel
        frame.pack();// Veličina našeg prozora je jednaka veličini našeg panela
        frame.setLocationRelativeTo(null);// Postavljanje prozora na sredinu ekreana
        frame.setVisible(true);// Prikaz prozora korisniku

        // Dodajemo akciju na dugme LogIn

        logInButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                onLogInButtonClicked();
                                          }
        });



    }

    //Poziva se klikom na dugme LogIn
    private void onLogInButtonClicked() {
        String enteredUser = txtUser.getText();
        String enteredPassword = new String(txtPassword.getPassword());

        // Provjeravamo korisnikove podatke

        if ("admin".equals(enteredUser) && "123".equals(enteredPassword)) {

            // Ako su podaci koje je korisnik unio jednaki podacima koje smo mi zadali ispisuje se poruka dobrodošlice

            JOptionPane.showMessageDialog(this, "Dobrodošli!", "Notification", JOptionPane.INFORMATION_MESSAGE);
            new Dobrodoslica(); // Otvoramo novu formu
            dispose(); // Zatvaramo trenutnu formu
        }

        else

        {

            // Ako je korisnik unio pogrešne podatke izlazi OptionDialog koji mu govori da su podaci pogrešni te mu nudi opciju da se ponovo LogIna ili izađe
            // Indijci na YouTube-u

            int option = JOptionPane.showOptionDialog(frame,
                    "Nepostojeći korisnik! Želite li pokušati ponovno?",
                    "Warning",

                    JOptionPane.YES_NO_OPTION,

                    JOptionPane.WARNING_MESSAGE,
                    null, // Ikona koja je prikazana
                    new Object[]{"LogIn", "Zatvori"},
                    "LogIn"); // Kada bi korinik pritisnuo enter išao bi na LogIn, jer smo stavili da je to vrijednost koja će biti označena



            if (option == JOptionPane.NO_OPTION) {
                System.exit(0); // Provjera da li je korisnik odabrao opciju zatvori, ako jeste program se zatvara
            }
        }
    }

        public static void main(String[] args) {
            SwingUtilities.invokeLater(() -> new LogIn());
    }  // Ovom linijom mi zapravo pokrećemo naš kod
}



