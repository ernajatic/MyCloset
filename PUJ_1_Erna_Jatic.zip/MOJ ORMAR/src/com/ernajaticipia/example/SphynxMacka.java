package com.ernajaticipia.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SphynxMacka extends JFrame{
    private JPanel panel1;
    private JTextPane sfinksMačkeSpadajuUTextPane;
    private JButton nazadButton;
    private JButton zatvoriButton;

    private JFrame frame;

    public SphynxMacka() {

        frame = new JFrame("Sfinks Mačka");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(400, 400));
        frame.setResizable(false);

        frame.add(panel1);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        nazadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Ormar();
                dispose();
            }
        });

        zatvoriButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }
}
