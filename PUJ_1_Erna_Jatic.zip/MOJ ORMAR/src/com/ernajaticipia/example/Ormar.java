package com.ernajaticipia.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ormar extends JFrame{
    private JButton maca1;
    private JButton maca2;
    private JButton maca3;
    private JButton maca4;
    private JButton maca5;
    private JButton maca6;
    private JButton maca7;
    private JButton maca8;
    private JButton maca9;
    private JPanel panel1;

    private JFrame frame;

    // Ormar pun maca

    public Ormar(){

        // Sve isto kao LogIn Frame osim veličine prozora

        frame = new JFrame("Moj Ormar");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(600, 600));
        frame.setResizable(false);

        frame.add(panel1);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // Pomoć od kolege
        // Slike su stavljene kao Buttoni te ih ima 9, kada korisnik klikne na button kreira se Action i povezujemo tu sliku sa narednom formom koja je vezana za nju.
        // Otvara se nardena forma i Ormar se dispose-a

        maca1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new TurskaAngora();
                dispose();
            }
        });

        maca2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PerzijskaMacka ();
                dispose();
            }
        });

        maca3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new NorveskaMacka ();
                dispose();
            }
        });

        maca4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new RuskaMacka();
                dispose();
            }
        });

        maca5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SphynxMacka();
                dispose();
            }
        });

        maca6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SkotskiFold ();
                dispose();
            }
        });

        maca7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new BritanskaMacka();
                dispose();
            }
        });

        maca8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SijamskaMacka();
                dispose();
            }
        });

        maca9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MunchkinMacka();
                dispose();
            }
        });
    }
}
